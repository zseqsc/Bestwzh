package first.zptc.cn.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity {
    private GridLayout gridLayout;
    private EditText editText;
//    String ss[]={"a1","a2","a3"};
//    int in[]=new int[3];
    Button button[]=new Button[18];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String str[]={"7","8","9","/","4","5","6","*","1","2","3","-","0",".","=","+","C","删除"};

        gridLayout= (GridLayout) findViewById(R.id.grid);
        for(int i=0;i<18;i++) {
            button[i]=new Button(this);
            button[i].setId(i);
            button[i].setText(str[i]);
            button[i].setOnClickListener(new btnListener());
            gridLayout.addView(button[i]);
        }
    }
    boolean bt=false;
    float n=0;
    float m=0;
    int x=0;
    int y=0;
    int z=0;
    class btnListener implements OnClickListener{
//        private Button btn;
            btnListener(){
            }


        @Override
        public void onClick(View v) {
            Log.d("hdf",bt+"");
            editText= (EditText) findViewById(R.id.etext);
            int id = v.getId();
            if(id==0){
                editText.append(""+7);
            }
            if(id==1){
                editText.append(""+8);
            }
            if(id==2){
                editText.append(""+9);
            }
            if(id==4){
                editText.append(""+4);
            }
            if(id==5){
                editText.append(""+5);
            }
            if(id==6){
                editText.append(""+6);
            }
            if(id==8){
                editText.append(""+1);
            }
            if(id==9){
                editText.append(""+2);
            }
            if(id==10) {
                editText.append(""+3);
            }
            if(id==12){
                editText.append(""+0);
            }
            if(id==13){
                editText.append(""+0);
            }
            // 除
            if (id==3){
                if(bt==false){
                    n=Float.parseFloat(editText.getText().toString());
                    bt=true;
                    x=4;
                    editText.setText("");
                    Log.d("hdf",bt+"");
                }
            }
            //乘
            if (id==7) {
                if (bt == false) {
                    n = Float.parseFloat(editText.getText().toString());
                    bt = true;
                    x = 3;
                    editText.setText("");
                    Log.d("hdf", bt + "");
                }
            }
            //减
            if (id==11) {
                if (bt == false) {
                    n = Float.parseFloat(editText.getText().toString());
                    bt = true;
                    x = 2;
                    editText.setText("");
                    Log.d("hdf", bt + "");
                }
            }
            //加
            if (id==15) {
                if (bt == false) {
                    n = Float.parseFloat(editText.getText().toString());
                    bt = true;
                    x = 1;
                    editText.setText("");
                    Log.d("hdf", bt + "");
                }
            }
            //等
            if (id==14){
                Log.d("hdf",bt+"2");
                if(bt==true){
                    m=Float.parseFloat(editText.getText().toString());
                    switch (x){
                        case 1:
                            n=n+m;
                            editText.setText(n+"");
                            break;
                        case 2:
                            n=n-m;
                            editText.setText(n+"");
                            break;
                        case 3:
                            n=n*m;
                            editText.setText(n+"");
                            break;
                        case 4:
                            if(m>0) {
                                n = n / m;
                                editText.setText(n+"");
                                break;
                            }
                            else{
                                editText.setText("被除数不能为0");
                             }
                    }
                    Log.d("hdf",bt+"1");
                    bt=false;
                }
            }
            if (id==13&&y==0){
                editText.append(".");
                y=1;
            }
            if(id==16){
                bt=false;
                n=0;
                m=0;
                x=0;
                y=0;
                editText.setText("");
            }
            if(id==17){
                editText.setText("");
                y=0;
            }
        }
    }
}
